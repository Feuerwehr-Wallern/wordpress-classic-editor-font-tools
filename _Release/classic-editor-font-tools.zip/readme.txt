﻿=== Classic Editor Zusatztool ===
Contributors: Stefan Schneebauer
Tags: classic editor, block editor, editor, gutenberg
Requires at least: 4.9
Tested up to: 6.9
Stable tag: 1.0.1
Requires PHP: 5.2.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Extends the WordPress Classic Editor with colors, styles, buttons, Font Awesome icons, and an emoji picker.

== Description ==
Dieses Plugin erweitert den WordPress Classic Editor um:
* Font-Auswahl
* Farben
* Button-Styles
* Font Awesome Icons
* Emoji Picker

== Installation ==
1. Plugin hochladen
2. Aktivieren

== Changelog ==
= 1.0.1 =
* Initiale Veröffentlichung

