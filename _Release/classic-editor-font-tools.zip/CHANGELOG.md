## [classic-editor-font-tools] v1.0.3 – 2026-02-03
- BugFix

## [classic-editor-font-tools] v1.0.2 â€“ 2026-02-03

## [classic-editor-font-tools] v1.0.1 Ã¢â‚¬â€œ 2026-02-02
- Initial Github Version

- BugFix

## [classic-editor-font-tools] v1.0.1 Ã¢â‚¬â€œ 2026-02-02
- Initial Github Version

